# AI-Powered Task Prioritization App

A to-do list application with AI-powered task prioritization using OpenAI's API.

## Features

- Create, update, and delete tasks
- Set task priorities, statuses, deadlines, and descriptions
- AI-powered task prioritization based on customizable factors:
  - Deadline importance
  - Required effort
  - Impact/value
- Filter tasks by priority or status
- Detailed task view with prioritization insights
- Responsive design for all devices

## Technology Stack

- **Frontend**: React, TypeScript, TailwindCSS, shadcn/ui
- **Backend**: Node.js, Express
- **State Management**: TanStack Query (React Query)
- **AI Integration**: OpenAI API with GPT-4o model
- **Form Handling**: React Hook Form with Zod validation

## Getting Started

### Prerequisites

- Node.js (v16+)
- npm or yarn
- OpenAI API key

### Installation

1. Clone the repository
   ```bash
   git clone https://github.com/yourusername/ai-task-prioritization.git
   cd ai-task-prioritization
   ```

2. Install dependencies
   ```bash
   npm install
   ```

3. Add your OpenAI API key
   Create a `.env` file in the root directory and add your OpenAI API key:
   ```
   OPENAI_API_KEY=your_openai_api_key
   ```

4. Start the development server
   ```bash
   npm run dev
   ```

5. Open [http://localhost:5000](http://localhost:5000) in your browser

## How It Works

1. **Task Creation**: Add new tasks with details like title, description, deadline, etc.
2. **Task Management**: Update, delete, or mark tasks as complete
3. **AI Prioritization**: Click "Prioritize Now" to have the AI analyze and prioritize your tasks
4. **Prioritization Settings**: Adjust the importance weights for different factors to customize prioritization
5. **Task Filtering**: Filter tasks by priority or status to focus on what matters most

## Environment Variables

- `OPENAI_API_KEY`: Your OpenAI API key (required for AI prioritization)

## License

MIT

## Acknowledgements

- [OpenAI](https://openai.com/) for their powerful language models
- [shadcn/ui](https://ui.shadcn.com/) for the beautiful UI components
- [TailwindCSS](https://tailwindcss.com/) for the utility-first CSS framework
- [Replit](https://replit.com/) for the development environment
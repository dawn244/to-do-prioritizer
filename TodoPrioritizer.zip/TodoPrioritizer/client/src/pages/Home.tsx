import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Task, FilterType, FilterValue, PrioritizationSettings } from "@/types";
import { useToast } from "@/hooks/use-toast";

import { Header } from "@/components/Header";
import { TaskInput } from "@/components/TaskInput";
import { TaskFilters } from "@/components/TaskFilters";
import { TaskList } from "@/components/TaskList";
import { TaskDetails } from "@/components/TaskDetails";
import { PrioritizationPanel } from "@/components/PrioritizationPanel";

import { InsertTask } from "@shared/schema";
import { prioritizeAllTasks } from "@/utils/prioritize";

export default function Home() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  // Task state
  const [selectedTask, setSelectedTask] = useState<Task | undefined>(undefined);
  const [editingTask, setEditingTask] = useState<Task | undefined>(undefined);
  const [filter, setFilter] = useState<{ type: FilterType; value: FilterValue }>({
    type: "all",
    value: "all",
  });
  
  // Prioritization state
  const [lastPrioritizationTime, setLastPrioritizationTime] = useState<string | null>(null);
  const [lastPrioritizationSummary, setLastPrioritizationSummary] = useState<string | null>(null);
  const [isPrioritizing, setIsPrioritizing] = useState(false);
  const [prioritizationError, setPrioritizationError] = useState<string | undefined>(undefined);

  // Fetch tasks
  const { 
    data: tasks = [], 
    isLoading: isLoadingTasks,
    isError: isTasksError,
    error: tasksError
  } = useQuery({ 
    queryKey: ["/api/tasks"],
    staleTime: 0 // Always refetch on load
  });

  // Create task mutation
  const createTaskMutation = useMutation({
    mutationFn: async (newTask: InsertTask) => {
      const response = await apiRequest("POST", "/api/tasks", newTask);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tasks"] });
      toast({
        title: "Success",
        description: "Your task has been added!",
      });
    },
    onError: (error) => {
      toast({
        variant: "destructive",
        title: "Error",
        description: `Failed to create task: ${error instanceof Error ? error.message : String(error)}`,
      });
    }
  });

  // Update task mutation
  const updateTaskMutation = useMutation({
    mutationFn: async ({ id, task }: { id: number; task: Partial<InsertTask> }) => {
      const response = await apiRequest("PATCH", `/api/tasks/${id}`, task);
      return response.json();
    },
    onSuccess: (updatedTask) => {
      queryClient.invalidateQueries({ queryKey: ["/api/tasks"] });
      setSelectedTask(updatedTask);
      setEditingTask(undefined);
      toast({
        title: "Success",
        description: "Your task has been updated!",
      });
    },
    onError: (error) => {
      toast({
        variant: "destructive",
        title: "Error",
        description: `Failed to update task: ${error instanceof Error ? error.message : String(error)}`,
      });
    }
  });

  // Delete task mutation
  const deleteTaskMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/tasks/${id}`);
      return id;
    },
    onSuccess: (id) => {
      queryClient.invalidateQueries({ queryKey: ["/api/tasks"] });
      if (selectedTask?.id === id) {
        setSelectedTask(undefined);
      }
      toast({
        title: "Success",
        description: "Your task has been deleted!",
      });
    },
    onError: (error) => {
      toast({
        variant: "destructive",
        title: "Error",
        description: `Failed to delete task: ${error instanceof Error ? error.message : String(error)}`,
      });
    }
  });

  // Form submission handlers
  const handleCreateTask = (data: InsertTask) => {
    createTaskMutation.mutate(data);
  };

  const handleUpdateTask = (data: InsertTask) => {
    if (editingTask) {
      updateTaskMutation.mutate({ id: editingTask.id, task: data });
    }
  };

  // Filtered tasks
  const filteredTasks = tasks.filter(task => {
    if (filter.type === "all") return true;
    if (filter.type === "priority") return task.priority === filter.value;
    if (filter.type === "status") return task.status === filter.value;
    return true;
  });

  // Task interaction handlers
  const handleEditTask = (task: Task) => {
    setEditingTask(task);
  };

  const handleCancelEdit = () => {
    setEditingTask(undefined);
  };

  const handleDeleteTask = (id: number) => {
    if (window.confirm("Are you sure you want to delete this task?")) {
      deleteTaskMutation.mutate(id);
    }
  };

  const handleSelectTask = (task: Task) => {
    setSelectedTask(task);
  };

  const handleStatusChange = (id: number, status: string) => {
    updateTaskMutation.mutate({ 
      id, 
      task: { 
        status,
        completedAt: status === "completed" ? new Date().toISOString() : null,
        completionPercentage: status === "completed" ? 100 : 0
      } 
    });
  };

  const handleCompleteTask = (id: number) => {
    handleStatusChange(id, "completed");
  };

  const handleFilterChange = (type: FilterType, value: FilterValue) => {
    setFilter({ type, value });
  };

  // Prioritization
  const handlePrioritize = async (settings: PrioritizationSettings) => {
    setIsPrioritizing(true);
    setPrioritizationError(undefined);
    
    try {
      const result = await prioritizeAllTasks(settings);
      
      // Update last prioritization time
      setLastPrioritizationTime(
        new Date().toLocaleString('en-US', {
          weekday: 'short',
          hour: '2-digit',
          minute: '2-digit'
        })
      );
      
      // Store summary if available
      if (result.summary) {
        setLastPrioritizationSummary(result.summary);
      }
      
      // Refetch tasks to get the updated priorities
      queryClient.invalidateQueries({ queryKey: ["/api/tasks"] });
      
      toast({
        title: "Success",
        description: "Your tasks have been prioritized!",
      });
    } catch (error) {
      setPrioritizationError(`Could not connect to the AI service. ${error instanceof Error ? error.message : "Please try again."}`);
      
      toast({
        variant: "destructive",
        title: "Error",
        description: `Failed to prioritize tasks: ${error instanceof Error ? error.message : String(error)}`,
      });
    } finally {
      setIsPrioritizing(false);
    }
  };

  const retryPrioritization = () => {
    setPrioritizationError(undefined);
  };

  // If a task is deleted that is currently selected, clear the selection
  useEffect(() => {
    if (selectedTask && !tasks.find(t => t.id === selectedTask.id)) {
      setSelectedTask(undefined);
    }
  }, [tasks, selectedTask]);

  return (
    <div className="container mx-auto px-4 py-8 max-w-5xl">
      <Header />
      
      <div className="md:flex md:space-x-6">
        <div className="mb-8 md:w-1/2 md:mb-0">
          {editingTask ? (
            <TaskInput 
              onSubmit={handleUpdateTask}
              onPrioritizeAll={() => {}} // Not needed for edit mode
              isEditMode={true}
              initialData={editingTask}
              onCancel={handleCancelEdit}
            />
          ) : (
            <TaskInput 
              onSubmit={handleCreateTask} 
              onPrioritizeAll={() => handlePrioritize({
                deadlineWeight: 4,
                effortWeight: 3,
                impactWeight: 5
              })}
            />
          )}
          
          <TaskFilters 
            onFilterChange={handleFilterChange} 
            currentFilter={filter}
          />
          
          <TaskList 
            tasks={filteredTasks}
            onEdit={handleEditTask}
            onDelete={handleDeleteTask}
            onSelect={handleSelectTask}
            onStatusChange={handleStatusChange}
            loading={isLoadingTasks}
          />
        </div>
        
        <div className="md:w-1/2">
          <PrioritizationPanel 
            onPrioritize={handlePrioritize}
            lastPrioritizationTime={lastPrioritizationTime}
            lastPrioritizationSummary={lastPrioritizationSummary}
            isPrioritizing={isPrioritizing}
          />
          
          <div className="bg-white rounded-lg shadow-sm p-4">
            <h2 className="text-lg font-medium mb-4">Task Details</h2>
            
            <TaskDetails 
              task={selectedTask}
              onComplete={handleCompleteTask}
              onEdit={handleEditTask}
              loading={isPrioritizing}
              error={prioritizationError}
              retryPrioritization={retryPrioritization}
            />
          </div>
        </div>
      </div>
    </div>
  );
}

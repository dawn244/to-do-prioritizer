import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";

// Add CSS for priority classes from design reference
const style = document.createElement('style');
style.textContent = `
  .priority-high {
    border-left: 4px solid #6D28D9;
  }
  .priority-medium {
    border-left: 4px solid #8B5CF6;
  }
  .priority-low {
    border-left: 4px solid #C4B5FD;
  }
  .rotate-animation {
    animation: rotate 1s linear infinite;
  }
  @keyframes rotate {
    from { transform: rotate(0deg); }
    to { transform: rotate(360deg); }
  }
`;
document.head.appendChild(style);

// Add Font Awesome for icons
const fontAwesome = document.createElement('link');
fontAwesome.rel = 'stylesheet';
fontAwesome.href = 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css';
document.head.appendChild(fontAwesome);

// Add Inter font from Google Fonts
const interFont = document.createElement('link');
interFont.rel = 'stylesheet';
interFont.href = 'https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap';
document.head.appendChild(interFont);

createRoot(document.getElementById("root")!).render(<App />);

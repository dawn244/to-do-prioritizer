import { Task, PrioritizationSettings } from "@shared/schema";

export type { Task, PrioritizationSettings };

export type FilterType = "all" | "priority" | "status";
export type FilterValue = 
  | "all" 
  | "high" 
  | "medium" 
  | "low" 
  | "pending" 
  | "in_progress" 
  | "completed";

export interface ToastProps {
  type: "success" | "error";
  title: string;
  message: string;
}

export interface PrioritizationResult {
  tasks: Task[];
  summary?: string;
}

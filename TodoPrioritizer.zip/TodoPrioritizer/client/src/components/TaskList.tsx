import { useState } from "react";
import { Task } from "@/types";
import { TaskItem } from "./TaskItem";
import { Button } from "@/components/ui/button";

interface TaskListProps {
  tasks: Task[];
  onEdit: (task: Task) => void;
  onDelete: (id: number) => void;
  onSelect: (task: Task) => void;
  onStatusChange: (id: number, status: string) => void;
  loading: boolean;
}

export function TaskList({ tasks, onEdit, onDelete, onSelect, onStatusChange, loading }: TaskListProps) {
  const totalTasks = tasks.length;
  const completedTasks = tasks.filter(task => task.status === "completed").length;

  // If we had a lot of tasks, we could implement pagination
  const [visibleTasks, setVisibleTasks] = useState(10);

  const loadMore = () => {
    setVisibleTasks(prev => prev + 10);
  };

  const displayedTasks = tasks.slice(0, visibleTasks);

  if (loading) {
    return (
      <div className="bg-white rounded-lg shadow-sm p-4">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-lg font-medium">Your Tasks</h2>
          <div className="text-sm text-gray-500">Loading...</div>
        </div>
        <div className="py-10 flex justify-center">
          <div className="animate-spin rounded-full h-8 w-8 border-2 border-primary border-t-transparent"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-lg shadow-sm p-4">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-lg font-medium">Your Tasks</h2>
        <div className="text-sm text-gray-500">
          <span>{completedTasks}</span>/<span>{totalTasks}</span> completed
        </div>
      </div>

      {tasks.length === 0 ? (
        <div className="text-center py-8">
          <div className="bg-gray-100 rounded-full h-16 w-16 flex items-center justify-center mx-auto mb-4">
            <i className="fas fa-tasks text-gray-400 text-xl"></i>
          </div>
          <h3 className="text-gray-700 font-medium mb-1">No tasks yet</h3>
          <p className="text-sm text-gray-500">Add a new task to get started!</p>
        </div>
      ) : (
        <div className="task-list space-y-3">
          {displayedTasks.map(task => (
            <TaskItem
              key={task.id}
              task={task}
              onEdit={onEdit}
              onDelete={onDelete}
              onSelect={onSelect}
              onStatusChange={onStatusChange}
            />
          ))}
        </div>
      )}

      {tasks.length > visibleTasks && (
        <div className="mt-4 text-center text-gray-500 text-sm pt-2 border-t border-gray-100">
          <Button 
            variant="link" 
            className="text-primary hover:text-indigo-700"
            onClick={loadMore}
          >
            Load more tasks
          </Button>
        </div>
      )}
    </div>
  );
}

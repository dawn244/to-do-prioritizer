import { useState } from "react";
import { Task } from "@/types";
import { formatDate, getPriorityBorder, getPriorityColor, getStatusColor } from "@/utils/prioritize";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Trash, Pencil } from "lucide-react";

interface TaskItemProps {
  task: Task;
  onEdit: (task: Task) => void;
  onDelete: (id: number) => void;
  onSelect: (task: Task) => void;
  onStatusChange: (id: number, status: string) => void;
}

export function TaskItem({ task, onEdit, onDelete, onSelect, onStatusChange }: TaskItemProps) {
  const isCompleted = task.status === "completed";
  
  const handleStatusToggle = () => {
    const newStatus = isCompleted ? "pending" : "completed";
    onStatusChange(task.id, newStatus);
  };

  return (
    <div 
      className={`task-item bg-white border border-gray-200 rounded-md p-3 hover:shadow-md transition ${getPriorityBorder(task.priority)} ${isCompleted ? 'opacity-70' : ''}`}
      onClick={() => onSelect(task)}
    >
      <div className="flex items-start justify-between">
        <div className="flex items-start space-x-3">
          <Checkbox 
            checked={isCompleted}
            onCheckedChange={handleStatusToggle}
            className={`mt-1 h-5 w-5 ${isCompleted ? 'bg-status-completed text-white' : ''}`}
            onClick={(e) => e.stopPropagation()}
          />
          <div>
            <h3 className={`font-medium text-gray-900 ${isCompleted ? 'line-through' : ''}`}>
              {task.title}
            </h3>
            {task.description && (
              <p className={`text-sm text-gray-600 mt-1 ${isCompleted ? 'line-through' : ''}`}>
                {task.description}
              </p>
            )}
            <div className="flex items-center mt-2 space-x-2 flex-wrap gap-y-1">
              <Badge variant={task.priority === "high" ? "highPriority" : task.priority === "medium" ? "mediumPriority" : "lowPriority"}>
                {task.priority.charAt(0).toUpperCase() + task.priority.slice(1)} Priority
              </Badge>
              
              <Badge variant={task.status === "completed" ? "completed" : task.status === "in_progress" ? "inProgress" : "pending"}>
                {task.status === "in_progress" 
                  ? "In Progress" 
                  : task.status.charAt(0).toUpperCase() + task.status.slice(1)}
              </Badge>
              
              {task.deadline && (
                <span className="text-xs text-gray-500">
                  Due: {formatDate(task.deadline)}
                </span>
              )}
              
              {isCompleted && task.completedAt && (
                <span className="text-xs text-gray-500">
                  Completed: {formatDate(task.completedAt)}
                </span>
              )}
            </div>
          </div>
        </div>
        <div className="flex space-x-1" onClick={(e) => e.stopPropagation()}>
          {!isCompleted && (
            <Button
              variant="ghost"
              size="icon"
              className="text-gray-400 hover:text-primary p-1 h-8 w-8"
              onClick={(e) => {
                e.stopPropagation();
                onEdit(task);
              }}
            >
              <Pencil className="h-4 w-4" />
            </Button>
          )}
          <Button
            variant="ghost"
            size="icon"
            className="text-gray-400 hover:text-status-error p-1 h-8 w-8"
            onClick={(e) => {
              e.stopPropagation();
              onDelete(task.id);
            }}
          >
            <Trash className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </div>
  );
}

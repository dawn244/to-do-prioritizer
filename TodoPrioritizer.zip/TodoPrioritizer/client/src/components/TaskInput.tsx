import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { InsertTask, insertTaskSchema } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Wand2 } from "lucide-react";
import { z } from "zod";

interface TaskInputProps {
  onSubmit: (data: InsertTask) => void;
  onPrioritizeAll: () => void;
  isEditMode?: boolean;
  initialData?: Partial<InsertTask>;
  onCancel?: () => void;
}

export function TaskInput({ 
  onSubmit, 
  onPrioritizeAll, 
  isEditMode = false,
  initialData,
  onCancel
}: TaskInputProps) {
  // Extend the schema to make validations stricter
  const formSchema = insertTaskSchema.extend({
    title: z.string().min(3, "Title must be at least 3 characters").max(100, "Title must be less than 100 characters"),
  });

  const form = useForm<InsertTask>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      title: initialData?.title || "",
      description: initialData?.description || "",
      deadline: initialData?.deadline || undefined,
      priority: initialData?.priority || "medium",
      status: initialData?.status || "pending",
      completionPercentage: initialData?.completionPercentage || 0
    }
  });

  const handleSubmit = (data: InsertTask) => {
    onSubmit(data);
    if (!isEditMode) {
      form.reset({
        title: "",
        description: "",
        deadline: undefined,
        priority: "medium",
        status: "pending",
        completionPercentage: 0
      });
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-sm p-4 mb-6">
      <h2 className="text-lg font-medium mb-4">{isEditMode ? "Edit Task" : "Add New Task"}</h2>
      <Form {...form}>
        <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
          <FormField
            control={form.control}
            name="title"
            render={({ field }) => (
              <FormItem>
                <FormLabel className="text-sm font-medium text-gray-700">Task Title</FormLabel>
                <FormControl>
                  <Input 
                    placeholder="What needs to be done?" 
                    className="w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                    {...field} 
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <FormField
            control={form.control}
            name="description"
            render={({ field }) => (
              <FormItem>
                <FormLabel className="text-sm font-medium text-gray-700">Description (optional)</FormLabel>
                <FormControl>
                  <Textarea 
                    placeholder="Add details about this task..." 
                    className="w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                    rows={3}
                    {...field} 
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <FormField
            control={form.control}
            name="deadline"
            render={({ field }) => (
              <FormItem>
                <FormLabel className="text-sm font-medium text-gray-700">Deadline (optional)</FormLabel>
                <FormControl>
                  <Input
                    type="date"
                    className="w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                    value={field.value ? new Date(field.value).toISOString().slice(0, 10) : ""}
                    onChange={(e) => {
                      const value = e.target.value ? new Date(e.target.value).toISOString() : undefined;
                      field.onChange(value);
                    }}
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <div className="flex justify-between">
            <div className="space-x-2">
              <Button type="submit">
                {isEditMode ? "Update Task" : "Add Task"}
              </Button>
              
              {isEditMode && onCancel && (
                <Button type="button" variant="outline" onClick={onCancel}>
                  Cancel
                </Button>
              )}
            </div>
            
            {!isEditMode && (
              <Button 
                type="button" 
                variant="outline" 
                className="flex items-center text-primary hover:text-indigo-700 border border-primary hover:border-indigo-700"
                onClick={onPrioritizeAll}
              >
                <Wand2 className="mr-2 h-4 w-4" /> Prioritize All Tasks
              </Button>
            )}
          </div>
        </form>
      </Form>
    </div>
  );
}

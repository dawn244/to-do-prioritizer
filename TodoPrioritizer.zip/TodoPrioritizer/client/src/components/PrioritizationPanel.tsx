import { useState, useEffect } from "react";
import { Slider } from "@/components/ui/slider";
import { Button } from "@/components/ui/button";
import { Settings } from "lucide-react";
import { 
  DEFAULT_PRIORITIZATION_SETTINGS, 
  getWeightLabel 
} from "@/utils/prioritize";
import { PrioritizationSettings } from "@/types";

interface PrioritizationPanelProps {
  onPrioritize: (settings: PrioritizationSettings) => void;
  lastPrioritizationTime: string | null;
  lastPrioritizationSummary: string | null;
  isPrioritizing: boolean;
}

export function PrioritizationPanel({ 
  onPrioritize, 
  lastPrioritizationTime,
  lastPrioritizationSummary,
  isPrioritizing
}: PrioritizationPanelProps) {
  const [settings, setSettings] = useState<PrioritizationSettings>(DEFAULT_PRIORITIZATION_SETTINGS);

  const handleChange = (key: keyof PrioritizationSettings, value: number[]) => {
    setSettings(prev => ({
      ...prev,
      [key]: value[0]
    }));
  };

  const handlePrioritizeNow = () => {
    onPrioritize(settings);
  };

  return (
    <div className="bg-white rounded-lg shadow-sm p-4 mb-6">
      <h2 className="text-lg font-medium mb-4">AI Prioritization</h2>
      
      <div className="bg-gray-50 border border-gray-200 rounded-md p-3 mb-4">
        <h3 className="font-medium text-sm text-gray-700 mb-2">How it works</h3>
        <p className="text-sm text-gray-600">
          Our AI analyzes your tasks based on deadlines, dependencies, importance, and effort to suggest the optimal order.
        </p>
      </div>
      
      <div id="prioritization-settings" className="mb-4">
        <h3 className="font-medium text-sm text-gray-700 mb-2">Prioritization Factors</h3>
        <div className="space-y-3">
          <div>
            <div className="flex justify-between text-sm mb-1">
              <label htmlFor="deadline-weight">Deadline Importance</label>
              <span className="text-gray-500">{getWeightLabel(settings.deadlineWeight)}</span>
            </div>
            <Slider
              id="deadline-weight"
              min={1}
              max={5}
              step={1}
              value={[settings.deadlineWeight]}
              onValueChange={(value) => handleChange("deadlineWeight", value)}
              className="w-full"
            />
          </div>
          <div>
            <div className="flex justify-between text-sm mb-1">
              <label htmlFor="effort-weight">Consider Effort Required</label>
              <span className="text-gray-500">{getWeightLabel(settings.effortWeight)}</span>
            </div>
            <Slider
              id="effort-weight"
              min={1}
              max={5}
              step={1}
              value={[settings.effortWeight]}
              onValueChange={(value) => handleChange("effortWeight", value)}
              className="w-full"
            />
          </div>
          <div>
            <div className="flex justify-between text-sm mb-1">
              <label htmlFor="impact-weight">Value/Impact Importance</label>
              <span className="text-gray-500">{getWeightLabel(settings.impactWeight)}</span>
            </div>
            <Slider
              id="impact-weight"
              min={1}
              max={5}
              step={1}
              value={[settings.impactWeight]}
              onValueChange={(value) => handleChange("impactWeight", value)}
              className="w-full"
            />
          </div>
        </div>
      </div>
      
      {lastPrioritizationTime && (
        <div className="bg-gray-50 border border-gray-200 rounded-md p-3 mb-4">
          <div className="flex items-center justify-between">
            <h3 className="font-medium text-sm text-gray-700">Last Prioritization</h3>
            <span className="text-xs text-gray-500">{lastPrioritizationTime}</span>
          </div>
          <p className="text-sm text-gray-600 mt-1">
            {lastPrioritizationSummary || "Tasks were reordered based on your prioritization settings."}
          </p>
        </div>
      )}
      
      <div className="flex justify-between">
        <Button 
          onClick={handlePrioritizeNow}
          disabled={isPrioritizing}
        >
          {isPrioritizing ? "Processing..." : "Prioritize Now"}
        </Button>
        <Button 
          variant="outline" 
          className="text-primary hover:text-indigo-700 border border-primary hover:border-indigo-700"
        >
          <Settings className="h-4 w-4 mr-1" /> Advanced Settings
        </Button>
      </div>
    </div>
  );
}

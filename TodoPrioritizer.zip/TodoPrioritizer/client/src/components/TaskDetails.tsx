import { useState } from "react";
import { Task } from "@/types";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { formatDate } from "@/utils/prioritize";
import { AlertCircle, CheckCircle, RefreshCw } from "lucide-react";

interface TaskDetailsProps {
  task?: Task;
  onComplete: (id: number) => void;
  onEdit: (task: Task) => void;
  loading: boolean;
  error?: string;
  retryPrioritization?: () => void;
}

export function TaskDetails({ 
  task, 
  onComplete, 
  onEdit, 
  loading,
  error,
  retryPrioritization
}: TaskDetailsProps) {
  const handleCompleteTask = () => {
    if (task) {
      onComplete(task.id);
    }
  };

  const handleEditTask = () => {
    if (task) {
      onEdit(task);
    }
  };

  // Render loading state
  if (loading) {
    return (
      <div id="prioritization-in-progress">
        <div className="text-center py-8">
          <div className="bg-indigo-100 rounded-full h-16 w-16 flex items-center justify-center mx-auto mb-4">
            <RefreshCw className="text-primary text-xl animate-spin" />
          </div>
          <h3 className="text-gray-700 font-medium mb-1">AI is prioritizing your tasks</h3>
          <p className="text-sm text-gray-500">This usually takes less than 15 seconds...</p>
          <div className="w-48 bg-gray-200 rounded-full h-1.5 mx-auto mt-4">
            <div className="bg-primary h-1.5 rounded-full animate-pulse" style={{ width: '70%' }}></div>
          </div>
        </div>
      </div>
    );
  }

  // Render error state
  if (error) {
    return (
      <div id="api-error">
        <div className="text-center py-8">
          <div className="bg-red-100 rounded-full h-16 w-16 flex items-center justify-center mx-auto mb-4">
            <AlertCircle className="text-status-error text-xl" />
          </div>
          <h3 className="text-gray-700 font-medium mb-1">Prioritization Failed</h3>
          <p className="text-sm text-gray-500 mb-4">{error}</p>
          {retryPrioritization && (
            <Button onClick={retryPrioritization}>
              Try Again
            </Button>
          )}
        </div>
      </div>
    );
  }

  // Render empty state
  if (!task) {
    return (
      <div id="no-task-selected">
        <div className="text-center py-8">
          <div className="bg-gray-100 rounded-full h-16 w-16 flex items-center justify-center mx-auto mb-4">
            <i className="fas fa-tasks text-gray-400 text-xl"></i>
          </div>
          <h3 className="text-gray-700 font-medium mb-1">No task selected</h3>
          <p className="text-sm text-gray-500">Select a task to view its details or add a new one.</p>
        </div>
      </div>
    );
  }

  // Render task details
  return (
    <div id="task-details">
      <div className="mb-6">
        <h3 className="text-xl font-medium text-gray-900">{task.title}</h3>
        <div className="flex items-center mt-2 space-x-2">
          <Badge variant={task.priority === "high" ? "highPriority" : task.priority === "medium" ? "mediumPriority" : "lowPriority"}>
            {task.priority.charAt(0).toUpperCase() + task.priority.slice(1)} Priority
          </Badge>
          <Badge variant={task.status === "completed" ? "completed" : task.status === "in_progress" ? "inProgress" : "pending"}>
            {task.status === "in_progress" 
              ? "In Progress" 
              : task.status.charAt(0).toUpperCase() + task.status.slice(1)}
          </Badge>
        </div>
      </div>
      
      <div className="space-y-4">
        <div>
          <h4 className="text-sm font-medium text-gray-700 mb-1">Description</h4>
          <p className="text-gray-600">
            {task.description || "No description provided."}
          </p>
        </div>
        
        <div className="grid grid-cols-2 gap-4">
          <div>
            <h4 className="text-sm font-medium text-gray-700 mb-1">Created</h4>
            <p className="text-gray-600">{formatDate(task.createdAt)}</p>
          </div>
          <div>
            <h4 className="text-sm font-medium text-gray-700 mb-1">Due Date</h4>
            <p className="text-gray-600">{task.deadline ? formatDate(task.deadline) : "No deadline"}</p>
          </div>
        </div>
        
        {task.priorityReason && (
          <div>
            <h4 className="text-sm font-medium text-gray-700 mb-1">Prioritization Insight</h4>
            <div className="bg-indigo-50 border border-indigo-100 rounded-md p-3">
              <p className="text-sm text-gray-700">
                <span className="font-medium">Why this is {task.priority} priority:</span>{" "}
                {task.priorityReason}
              </p>
            </div>
          </div>
        )}
        
        <div>
          <h4 className="text-sm font-medium text-gray-700 mb-1">Completion Status</h4>
          <Progress value={task.completionPercentage || 0} className="w-full h-2.5" />
          <div className="flex justify-between mt-1">
            <span className="text-xs text-gray-500">{task.completionPercentage || 0}% complete</span>
          </div>
        </div>
      </div>
      
      <div className="mt-6 pt-4 border-t border-gray-100 flex space-x-2">
        {task.status !== "completed" ? (
          <>
            <Button 
              className="flex-1"
              onClick={handleCompleteTask}
            >
              Mark Complete
            </Button>
            <Button 
              variant="outline" 
              className="flex-1"
              onClick={handleEditTask}
            >
              Edit Task
            </Button>
          </>
        ) : (
          <Button 
            variant="outline" 
            className="flex-1"
            onClick={handleEditTask}
          >
            View Details
          </Button>
        )}
      </div>
    </div>
  );
}

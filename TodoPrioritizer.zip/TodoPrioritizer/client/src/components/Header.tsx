import { useState, useEffect } from "react";
import { useToast } from "@/hooks/use-toast";

export function Header() {
  const [darkMode, setDarkMode] = useState(false);
  const { toast } = useToast();

  // Toggle dark mode
  const toggleDarkMode = () => {
    setDarkMode(!darkMode);
    // This would normally also set a class on the html element or use a context
    toast({
      title: darkMode ? "Light Mode Activated" : "Dark Mode Activated",
      description: "Your preference has been saved.",
    });
  };

  return (
    <header className="mb-8">
      <div className="flex items-center justify-between mb-4">
        <h1 className="text-2xl font-semibold flex items-center">
          <span className="text-primary mr-2">Priority Planner</span>
          <span className="text-sm bg-primary text-white px-2 py-1 rounded">LLM-Powered</span>
        </h1>
        <div className="flex space-x-2">
          <button 
            onClick={toggleDarkMode}
            className="p-2 rounded-full hover:bg-gray-200"
          >
            <i className={`fas ${darkMode ? 'fa-sun' : 'fa-moon'}`}></i>
          </button>
          <button className="bg-primary text-white rounded-full h-8 w-8 flex items-center justify-center">
            <span className="text-sm">JD</span>
          </button>
        </div>
      </div>
      <p className="text-gray-600 text-sm">
        AI-powered task prioritization to help you focus on what matters most.
      </p>
    </header>
  );
}

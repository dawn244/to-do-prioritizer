import { useState } from "react";
import { Button } from "@/components/ui/button";
import { FilterType, FilterValue } from "@/types";

interface TaskFiltersProps {
  onFilterChange: (type: FilterType, value: FilterValue) => void;
  currentFilter: { type: FilterType; value: FilterValue };
}

export function TaskFilters({ onFilterChange, currentFilter }: TaskFiltersProps) {
  const getButtonStyle = (type: FilterType, value: FilterValue) => {
    const isActive = 
      currentFilter.type === type && 
      (currentFilter.value === value || (currentFilter.type === type && value === "all"));
    
    return isActive 
      ? "bg-primary text-white" 
      : "bg-gray-200 text-gray-700 hover:bg-primary hover:text-white transition";
  };

  return (
    <div className="bg-white rounded-lg shadow-sm p-4 mb-6">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-lg font-medium">Filters</h2>
        <button 
          onClick={() => onFilterChange("all", "all")}
          className="text-sm text-gray-500 hover:text-primary"
        >
          Clear All
        </button>
      </div>
      <div className="flex flex-wrap gap-2">
        <button 
          className={`px-3 py-1 rounded-full text-sm ${getButtonStyle("all", "all")}`}
          onClick={() => onFilterChange("all", "all")}
        >
          All Tasks
        </button>
        <button 
          className={`px-3 py-1 rounded-full text-sm ${getButtonStyle("priority", "high")}`}
          onClick={() => onFilterChange("priority", "high")}
        >
          High Priority
        </button>
        <button 
          className={`px-3 py-1 rounded-full text-sm ${getButtonStyle("priority", "medium")}`}
          onClick={() => onFilterChange("priority", "medium")}
        >
          Medium Priority
        </button>
        <button 
          className={`px-3 py-1 rounded-full text-sm ${getButtonStyle("priority", "low")}`}
          onClick={() => onFilterChange("priority", "low")}
        >
          Low Priority
        </button>
        <button 
          className={`px-3 py-1 rounded-full text-sm ${getButtonStyle("status", "completed")}`}
          onClick={() => onFilterChange("status", "completed")}
        >
          Completed
        </button>
        <button 
          className={`px-3 py-1 rounded-full text-sm ${getButtonStyle("status", "in_progress")}`}
          onClick={() => onFilterChange("status", "in_progress")}
        >
          In Progress
        </button>
      </div>
    </div>
  );
}

import { apiRequest } from "@/lib/queryClient";
import { Task, PrioritizationSettings, PrioritizationResult } from "@/types";

export const DEFAULT_PRIORITIZATION_SETTINGS: PrioritizationSettings = {
  deadlineWeight: 4,
  effortWeight: 3,
  impactWeight: 5,
};

export const prioritizeAllTasks = async (
  settings: PrioritizationSettings = DEFAULT_PRIORITIZATION_SETTINGS
): Promise<PrioritizationResult> => {
  const response = await apiRequest("POST", "/api/prioritize", settings);
  const result: PrioritizationResult = await response.json();
  return result;
};

export const getWeightLabel = (weight: number): string => {
  switch (weight) {
    case 1:
      return "Very Low";
    case 2:
      return "Low";
    case 3:
      return "Medium";
    case 4:
      return "High";
    case 5:
      return "Very High";
    default:
      return "Medium";
  }
};

export const getPriorityColor = (priority: string): string => {
  switch (priority) {
    case "high":
      return "bg-accent-dark text-white";
    case "medium":
      return "bg-accent text-white";
    case "low":
      return "bg-accent-light text-gray-800";
    case "completed":
      return "bg-status-completed text-white";
    default:
      return "bg-gray-500 text-white";
  }
};

export const getStatusColor = (status: string): string => {
  switch (status) {
    case "pending":
      return "bg-gray-500 text-white";
    case "in_progress":
      return "bg-status-inProgress text-white";
    case "completed":
      return "bg-status-completed text-white";
    default:
      return "bg-gray-500 text-white";
  }
};

export const getPriorityBorder = (priority: string): string => {
  switch (priority) {
    case "high":
      return "priority-high";
    case "medium":
      return "priority-medium";
    case "low":
      return "priority-low";
    default:
      return "";
  }
};

export const formatDate = (date: Date | null | undefined): string => {
  if (!date) return "";
  return new Date(date).toLocaleDateString("en-US", {
    month: "short",
    day: "numeric",
    year: "numeric"
  });
};

import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { prioritizeTasks } from "./openai";
import { 
  insertTaskSchema, 
  updateTaskSchema, 
  prioritizationSettingsSchema
} from "@shared/schema";
import { ZodError } from "zod";
import { fromZodError } from "zod-validation-error";

export async function registerRoutes(app: Express): Promise<Server> {
  // Task routes
  app.get("/api/tasks", async (req: Request, res: Response) => {
    try {
      const tasks = await storage.getTasks();
      return res.json(tasks);
    } catch (error) {
      console.error("Error getting tasks:", error);
      return res.status(500).json({ message: "Failed to get tasks" });
    }
  });

  app.get("/api/tasks/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid task ID" });
      }

      const task = await storage.getTask(id);
      if (!task) {
        return res.status(404).json({ message: "Task not found" });
      }

      return res.json(task);
    } catch (error) {
      console.error("Error getting task:", error);
      return res.status(500).json({ message: "Failed to get task" });
    }
  });

  app.post("/api/tasks", async (req: Request, res: Response) => {
    try {
      const validatedData = insertTaskSchema.parse(req.body);
      const task = await storage.createTask(validatedData);
      return res.status(201).json(task);
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: validationError.message });
      }
      console.error("Error creating task:", error);
      return res.status(500).json({ message: "Failed to create task" });
    }
  });

  app.patch("/api/tasks/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid task ID" });
      }

      const task = await storage.getTask(id);
      if (!task) {
        return res.status(404).json({ message: "Task not found" });
      }

      // Partial validation of update data
      const updateData = updateTaskSchema.partial().parse(req.body);
      const updatedTask = await storage.updateTask(id, updateData);
      
      return res.json(updatedTask);
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: validationError.message });
      }
      console.error("Error updating task:", error);
      return res.status(500).json({ message: "Failed to update task" });
    }
  });

  app.delete("/api/tasks/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid task ID" });
      }

      const task = await storage.getTask(id);
      if (!task) {
        return res.status(404).json({ message: "Task not found" });
      }

      await storage.deleteTask(id);
      return res.status(204).send();
    } catch (error) {
      console.error("Error deleting task:", error);
      return res.status(500).json({ message: "Failed to delete task" });
    }
  });

  app.get("/api/tasks/filter/status/:status", async (req: Request, res: Response) => {
    try {
      const { status } = req.params;
      const tasks = await storage.getTasksByStatus(status);
      return res.json(tasks);
    } catch (error) {
      console.error("Error filtering tasks by status:", error);
      return res.status(500).json({ message: "Failed to filter tasks by status" });
    }
  });

  app.get("/api/tasks/filter/priority/:priority", async (req: Request, res: Response) => {
    try {
      const { priority } = req.params;
      const tasks = await storage.getTasksByPriority(priority);
      return res.json(tasks);
    } catch (error) {
      console.error("Error filtering tasks by priority:", error);
      return res.status(500).json({ message: "Failed to filter tasks by priority" });
    }
  });

  // AI Prioritization
  app.post("/api/prioritize", async (req: Request, res: Response) => {
    try {
      const tasks = await storage.getTasks();
      if (tasks.length === 0) {
        return res.json({ message: "No tasks to prioritize" });
      }

      // Validate the prioritization settings
      const settings = prioritizationSettingsSchema.parse(req.body);
      
      // Call the OpenAI API to prioritize tasks
      const prioritizationResult = await prioritizeTasks(tasks, settings);
      
      // Update the tasks with new priorities
      const updatedTasks = await storage.updateTaskPriorities(prioritizationResult.tasks);
      
      return res.json({
        tasks: updatedTasks,
        summary: prioritizationResult.summary
      });
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: validationError.message });
      }
      console.error("Error prioritizing tasks:", error);
      return res.status(500).json({ 
        message: "Failed to prioritize tasks", 
        error: error instanceof Error ? error.message : String(error)
      });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}

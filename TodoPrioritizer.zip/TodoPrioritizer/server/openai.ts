import OpenAI from "openai";
import { Task, PrioritizationSettings } from "@shared/schema";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const OPENAI_MODEL = "gpt-4o";

const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY 
});

interface PrioritizationResult {
  tasks: {
    id: number;
    priority: "high" | "medium" | "low";
    priorityScore: number;
    priorityReason: string;
  }[];
  summary?: string;
}

export async function prioritizeTasks(
  tasks: Task[],
  settings: PrioritizationSettings
): Promise<PrioritizationResult> {
  if (tasks.length === 0) {
    return { tasks: [] };
  }

  try {
    const prompt = createPrioritizationPrompt(tasks, settings);

    const response = await openai.chat.completions.create({
      model: OPENAI_MODEL,
      messages: [
        {
          role: "system",
          content: 
            "You are an AI task prioritization assistant. Your job is to analyze the tasks provided and prioritize them based on deadlines, importance, impact, and effort required. Always output valid JSON in the specified format."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      response_format: { type: "json_object" }
    });

    const content = response.choices[0].message.content;
    if (!content) {
      throw new Error("Empty response from OpenAI");
    }

    const result = JSON.parse(content) as PrioritizationResult;
    return result;
  } catch (error) {
    console.error("Error prioritizing tasks:", error);
    throw new Error(`Failed to prioritize tasks: ${error instanceof Error ? error.message : String(error)}`);
  }
}

function createPrioritizationPrompt(tasks: Task[], settings: PrioritizationSettings): string {
  const taskDetails = tasks.map(task => ({
    id: task.id,
    title: task.title,
    description: task.description || "",
    deadline: task.deadline ? new Date(task.deadline).toISOString() : null,
    status: task.status,
    createdAt: task.createdAt ? new Date(task.createdAt).toISOString() : null,
    completionPercentage: task.completionPercentage || 0
  }));

  return `
Please analyze and prioritize the following tasks based on these weights:
- Deadline Importance: ${settings.deadlineWeight}/5
- Effort Required: ${settings.effortWeight}/5
- Value/Impact: ${settings.impactWeight}/5

Tasks to prioritize:
${JSON.stringify(taskDetails, null, 2)}

Classify each task as 'high', 'medium', or 'low' priority. Assign a numerical priority score (1-100) where higher values indicate higher priority.
For each task, provide a brief reason for the assigned priority level.

Respond with a JSON object in this exact format:
{
  "tasks": [
    {
      "id": number,
      "priority": "high" | "medium" | "low",
      "priorityScore": number,
      "priorityReason": string
    }
  ],
  "summary": string
}

The summary should briefly explain the overall prioritization approach.
`;
}

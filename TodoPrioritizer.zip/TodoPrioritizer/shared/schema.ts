import { pgTable, text, serial, integer, boolean, timestamp, pgEnum } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User schema (kept from the original schema)
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Create enums for task status and priority
export const taskPriorityEnum = pgEnum("task_priority", ["high", "medium", "low"]);
export const taskStatusEnum = pgEnum("task_status", ["pending", "in_progress", "completed"]);

// Tasks schema
export const tasks = pgTable("tasks", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description"),
  deadline: timestamp("deadline"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  completedAt: timestamp("completed_at"),
  priority: text("priority").notNull().default("medium"),
  status: text("status").notNull().default("pending"),
  priorityScore: integer("priority_score"),
  priorityReason: text("priority_reason"),
  completionPercentage: integer("completion_percentage").default(0),
});

export const insertTaskSchema = createInsertSchema(tasks).omit({ 
  id: true,
  createdAt: true,
  completedAt: true,
  priorityScore: true,
  priorityReason: true
});

export const updateTaskSchema = createInsertSchema(tasks).omit({ 
  id: true, 
  createdAt: true 
});

// Extract types
export type InsertTask = z.infer<typeof insertTaskSchema>;
export type UpdateTask = z.infer<typeof updateTaskSchema>;
export type Task = typeof tasks.$inferSelect;

// PrioritizationSettings for AI customization
export const prioritizationSettingsSchema = z.object({
  deadlineWeight: z.number().min(1).max(5).default(4),
  effortWeight: z.number().min(1).max(5).default(3),
  impactWeight: z.number().min(1).max(5).default(5),
});

export type PrioritizationSettings = z.infer<typeof prioritizationSettingsSchema>;
